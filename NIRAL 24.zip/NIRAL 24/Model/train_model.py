# model/train_model.py

import torch
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset
from model import SimpleNN


class CustomDataset(Dataset):
    def __init__(self, data, labels):
        self.data = data
        self.labels = labels

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx], self.labels[idx]


def train_model():
    # Example data - replace with actual data loading
    X_train = torch.randn(100, 50)  # 100 samples, 50 features
    y_train = torch.randint(0, 2, (100,))  # Binary classification

    dataset = CustomDataset(X_train, y_train)
    dataloader = DataLoader(dataset, batch_size=10, shuffle=True)

    model = SimpleNN(input_dim=50, hidden_dim=20, output_dim=2)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)

    for epoch in range(5):
        for data, labels in dataloader:
            optimizer.zero_grad()
            outputs = model(data)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

        print(f'Epoch {epoch + 1}, Loss: {loss.item()}')


if __name__ == "__main__":
    train_model()
