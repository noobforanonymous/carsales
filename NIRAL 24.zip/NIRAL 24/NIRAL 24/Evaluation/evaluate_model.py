# evaluation/evaluate_model.py

import torch
from model import SimpleNN
from torch.utils.data import DataLoader, Dataset


class CustomDataset(Dataset):
    # Same as in train_model.py
    pass


def evaluate_model():
    # Example data - replace with actual test data loading
    X_test = torch.randn(20, 50)  # 20 samples, 50 features
    y_test = torch.randint(0, 2, (20,))  # Binary classification

    dataset = CustomDataset(X_test, y_test)
    dataloader = DataLoader(dataset, batch_size=5, shuffle=False)

    model = SimpleNN(input_dim=50, hidden_dim=20, output_dim=2)
    model.load_state_dict(torch.load('model.pth'))
    model.eval()

    correct = 0
    total = 0

    with torch.no_grad():
        for data, labels in dataloader:
            outputs = model(data)
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

    accuracy = correct / total
    print(f'Accuracy: {accuracy * 100:.2f}%')


if __name__ == "__main__":
    evaluate_model()
