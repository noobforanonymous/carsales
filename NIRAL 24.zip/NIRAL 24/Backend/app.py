# backend/app.py

from flask import Flask, request, jsonify
import torch
from model import SimpleNN
import json

app = Flask(__name__)

# Load model
model = SimpleNN(input_dim=50, hidden_dim=20, output_dim=2)  # Adjust as needed
model.load_state_dict(torch.load('model.pth'))
model.eval()

@app.route('/upload', methods=['POST'])
def upload_file():
    file = request.files['file']
    if file and file.filename.endswith('.txt'):
        text = file.read().decode('utf-8')
        # Process text and make prediction
        # Example: Convert text to feature vector (dummy example)
        features = torch.randn(1, 50)  # Replace with actual feature extraction
        with torch.no_grad():
            prediction = model(features)
        result = {"prediction": prediction.numpy().tolist()}
        return jsonify(result)
    else:
        return jsonify({"error": "Invalid file type"}), 400

if __name__ == "__main__":
    app.run(debug=True)
