# preprocessing/data_preprocessing.py

import os
import pandas as pd
from nltk.tokenize import word_tokenize
import nltk

nltk.download('punkt')


def preprocess_text(text):
    # Tokenization and basic preprocessing
    tokens = word_tokenize(text.lower())
    tokens = [word for word in tokens if word.isalnum()]
    return ' '.join(tokens)


def preprocess_data(raw_data_dir, preprocessed_data_dir):
    # Ensure output directory exists
    os.makedirs(preprocessed_data_dir, exist_ok=True)

    for filename in os.listdir(raw_data_dir):
        if filename.endswith(".txt"):
            with open(os.path.join(raw_data_dir, filename), 'r') as file:
                text = file.read()
                preprocessed_text = preprocess_text(text)
                with open(os.path.join(preprocessed_data_dir, filename), 'w') as out_file:
                    out_file.write(preprocessed_text)


if __name__ == "__main__":
    preprocess_data('data/raw', 'data/preprocessed')
